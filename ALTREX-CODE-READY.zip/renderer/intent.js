'use strict';
// Pure helpers (also loaded by the node tests).
(function (g) {
  // Code is hidden by default. It is shown in the chat only when the user explicitly asks for it.
  const NO_CODE = /\b(no|not|dont|don't|do not|without|never|stop|avoid|hide|skip|nothing)\b[^.\n]{0,30}\b(codes?|source|snippets?)\b/i;
  const SHOW = /\b(show|give|write|print|paste|display|send|see|need|want|share|post)\b[^.\n]{0,30}\b(codes?|source|snippets?)\b|\bsource code\b|\bcode (please|pls|now)\b|\bwhat('?s| is) the code\b/i;
  const IMAGE = /\b(generate|create|make|draw|paint|render|produce|give me|show me)\b[^.\n]{0,40}\b(images?|imgs?|pictures?|pics?|photos?|illustrations?|artworks?|wallpapers?|posters?|paintings?|logos?)\b/i;
  const WEBISH = /\b(web ?pages?|wb ?pg|web ?pg|web ?sites?|wbsite|sites?|pages?|html|css|apps?|applications?|dashboard|portfolio|landing)\b/i;
  // 'code' = show code in the chat (only when asked). 'image' = AI image generation. 'build' = everything else: files are saved, code stays hidden.
  function intent(text) {
    const t = String(text || '');
    if (NO_CODE.test(t)) return 'build';
    if (/\bsvg\b/i.test(t)) return SHOW.test(t) ? 'code' : 'build';
    if (SHOW.test(t)) return 'code';
    if (IMAGE.test(t) && !WEBISH.test(t)) return 'image';
    return 'build';
  }
  const EXT = { javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', python: 'py', py: 'py', html: 'html', css: 'css', json: 'json', bash: 'sh', sh: 'sh', markdown: 'md', md: 'md', tsx: 'tsx', jsx: 'jsx' };
  function blocks(text) {
    const re = /```([^\n`]*)\n([\s\S]*?)```/g; let m, n = 0; const out = [];
    while ((m = re.exec(text))) {
      n++; const info = m[1].trim(), lang = (info.split(/\s+/)[0] || '').toLowerCase(), fm = info.match(/filename=([^\s]+)/);
      let name = fm ? fm[1] : (lang === 'html' && n === 1 ? 'index.html' : 'file-' + n + '.' + (EXT[lang] || 'txt'));
      out.push({ name: name.replace(/^["']|["']$/g, ''), content: m[2] });
    } return out;
  }
  // Text shown in chat when code must stay hidden: removes finished blocks and any block still streaming.
  function stripCode(text) {
    let s = String(text).replace(/```[^\n`]*\n[\s\S]*?```/g, '');
    const open = s.indexOf('```'); if (open >= 0) s = s.slice(0, open) + '\n(writing the file…)';
    return s.replace(/\n{3,}/g, '\n\n').trim();
  }
  const OPENABLE = ['html', 'htm', 'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'txt', 'md', 'json', 'css', 'csv', 'pdf'];
  const canOpen = (n) => String(n).includes('.') && OPENABLE.includes(String(n).split('.').pop().toLowerCase());
  const api = { intent, blocks, stripCode, canOpen };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else g.AltrexIntent = api;
})(typeof window !== 'undefined' ? window : globalThis);
