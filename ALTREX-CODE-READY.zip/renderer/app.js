'use strict';
const $ = (s) => document.querySelector(s);
const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x !== undefined) e.textContent = x; return e; };
const { intent, blocks, stripCode, canOpen } = window.AltrexIntent;
let nextMode = null;
let trimmed = false, lastTyped = '', lastImages = [];
let state = { consent: false, active: null, providers: [] }, route = null, busy = false, taskId = null, cur = null, curMode = 'code', curHadImages = false;
const hist = [], atts = [], MAX_FILES = 200, MAX_TXT = 400000, MAX_TOTAL = 2000000, MAX_IMG = 60, MAX_IMG_BYTES = 25e6, MAX_IMG_TOTAL = 60e6;
const IMG_OK = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
const TEXT_EXT = /\.(txt|md|json|csv|js|ts|tsx|jsx|py|html?|css|java|c|h|cpp|cs|go|rs|php|rb|sh|yml|yaml|xml|sql|log|ini|toml|env|gitignore)$/i;

function badge() { const b = $('#badge'); b.textContent = route ? route.provider + ' • ' + route.model : 'No active route'; }
function addMsg(cls, text) { const h = $('#hello'); if (h) h.remove(); const d = el('div', 'msg ' + cls, text); $('#chat').appendChild(d); $('#thread').scrollTop = 1e9; return d; }
function grow() { const t = $('#cmd'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, innerHeight * 0.4) + 'px'; }
function chips() { const c = $('#chips'); c.innerHTML = ''; atts.forEach((a, i) => { const e = el('span', 'chip'); if (a.dataUrl) { const im = el('img', 'thumb'); im.src = a.dataUrl; im.alt = ''; e.appendChild(im); } const x = el('button', '', '×'); x.setAttribute('aria-label', 'Remove ' + a.name); x.onclick = () => { atts.splice(i, 1); chips(); }; e.append(el('span', '', a.name), x); c.appendChild(e); }); }
async function shrink(f) { // keeps many large photos within provider request limits
  const type = f.type === 'image/png' ? 'image/png' : 'image/jpeg';
  if (f.type === 'image/gif' || f.size < 1.2e6) return readDataUrl(f);
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    const out = c.toDataURL(type === 'image/png' && f.size < 4e6 ? 'image/png' : 'image/jpeg', 0.85); bmp.close && bmp.close(); return out.length < f.size * 1.4 + 1000 ? out : readDataUrl(f);
  } catch (e) { return readDataUrl(f); }
}
const readDataUrl = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(f); });
async function addFiles(list) {
  for (const f of list) {
    try {
      if (f.type.startsWith('image/')) {
        if (!IMG_OK.includes(f.type)) { addMsg('sys', f.name + ': use PNG, JPEG, GIF or WebP images.'); continue; }
        if (f.size > MAX_IMG_BYTES) { addMsg('sys', f.name + ' is too large (max 25 MB per image).'); continue; }
        if (atts.filter((a) => a.dataUrl).length >= MAX_IMG) { addMsg('sys', 'You can attach up to ' + MAX_IMG + ' images at once.'); continue; }
        const du = await shrink(f); if (atts.reduce((n, a) => n + (a.dataUrl ? a.dataUrl.length : 0), 0) + du.length > MAX_IMG_TOTAL) { addMsg('sys', 'Total image size is too large; send the rest in another message.'); continue; }
        atts.push({ name: f.name, dataUrl: du });
      } else {
        if (f.size > 10e6) { addMsg('sys', f.name + ' is too large (max 10 MB).'); continue; }
        if (atts.length >= MAX_FILES) { addMsg('sys', 'You can attach up to ' + MAX_FILES + ' items at once.'); continue; }
        const t = await f.text();
        if (t.slice(0, 4000).includes('\u0000') || (!TEXT_EXT.test(f.name) && /[\uFFFD]/.test(t.slice(0, 4000)))) { addMsg('sys', f.name + ' is not a text or code file. Attach text, code or images (PDF and Word files are not supported yet).'); continue; }
        atts.push({ name: f.name, text: t.slice(0, MAX_TXT), cut: t.length > MAX_TXT });
      }
    } catch (e) { addMsg('sys', 'Could not attach ' + f.name + '.'); }
  } chips();
}
function downloads(host, text) {
  const list = blocks(text); if (!list.length) return; const w = el('div', 'row');
  list.forEach((bl) => { const name = bl.name.replace(/[\\/:*?"<>|]/g, '_'); const b = el('button', '', 'Download ' + name);
    b.onclick = () => { const a = el('a'); a.href = URL.createObjectURL(new Blob([bl.content], { type: 'text/plain' })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); }; w.appendChild(b); });
  host.appendChild(w);
}
async function fileCards(host, text) {
  const list = blocks(text); if (!list.length) return false;
  const r = await window.altrex.saveFiles(list.map((b) => ({ name: b.name, content: b.content })));
  if (r.error) { host.appendChild(el('div', 'sub', 'Could not save the files: ' + r.error.message)); downloads(host, text); return true; }
  const main = r.files.find((f) => /\.html?$/i.test(f.name)) || r.files[0];
  r.files.forEach((f) => { const c = el('div', 'file'); c.append(el('span', 'nm', f.name));
    const rev = el('button', '', 'Show in folder'); rev.onclick = () => window.altrex.revealPath(f.path);
    if (canOpen(f.name)) { const open = el('button', f === main ? 'pri' : '', 'Open'); open.onclick = () => window.altrex.openPath(f.path); c.append(open); }
    c.append(rev, el('div', 'pth', f.path)); host.appendChild(c); });
  if (r.files.some((f) => /^build\.(bat|cmd)$/i.test(f.name))) buildCard(host, r.dir);
  return true;
}
const BUILD_RULES = ' A build.bat must start with @echo off and cd /d "%~dp0", use only normal build tools (pip install pyinstaller, pyinstaller --onefile, dotnet publish, npm, go build, cargo build), only touch files inside its own folder (no absolute paths, no .., no system or registry changes, no downloads with curl or powershell), check that the needed tool exists, and put the finished .exe in a dist folder.';
const SYS = 'You are ALTREX, an AI coding assistant. Be direct and concise. ALTREX saves every file you write in a fenced block on the user\'s PC and shows an Open button, so never say you cannot create or save files and never tell the user to copy and paste. ALTREX cannot compile programs or render video itself: if asked for an .exe, write the program as source files plus a build.bat, and say the user can press the Build button ALTREX shows after reviewing the script; if asked for a video, make an animated HTML or SVG page instead unless a video provider is connected, and say so plainly.';
const SYS_BUILD = 'Do NOT put code in your chat reply unless the user explicitly asks to see it. If the request needs code or a file (a web page, app, script, document, etc.), reply with one or two short plain sentences about what you made, and put every file in a fenced block opening with ```lang filename=NAME with complete working contents: ALTREX saves those files and hides the code from the user, so never repeat the code outside the blocks. For a web page make one self-contained index.html with inline CSS and JS unless asked otherwise. If no file is needed (greetings, questions, advice), just answer in plain prose with no code blocks. Never ask whether the user wants code.';
const SYS_CODE = 'The user explicitly asked to see the code. Show it in the reply in fenced blocks (```lang filename=NAME) with a brief explanation.';
async function send() {
  const typed = $('#cmd').value.trim(); if ((!typed && !atts.length) || busy) return;
  const sent = atts.splice(0); chips(); $('#cmd').value = ''; grow();
  let budget = MAX_TOTAL, t = typed || 'Please look at the attached file(s).';
  for (const a of sent) { if (a.text === undefined) continue; const p = a.text.slice(0, Math.max(0, budget)); budget -= p.length; t += '\n\n[Attached file: ' + a.name + (a.cut || p.length < a.text.length ? ' (truncated)' : '') + ']\n' + p; }
  const images = sent.filter((a) => a.dataUrl);
  const u = addMsg('you', typed + (sent.length ? '  📎 ' + sent.map((a) => a.name).join(', ') : ''));
  curMode = nextMode ? nextMode : sent.length ? (intent(typed) === 'image' ? 'build' : intent(typed)) : intent(typed); curHadImages = images.length > 0;
  nextMode = null; busy = true; $('#send').disabled = true; $('#stop').hidden = false; newTask(); cur = addMsg('', 'Thinking…');
  if (curMode === 'image') { await makeImage(typed); return; }
  hist.push({ role: 'user', content: t }); trimmed = false; lastImages = images;
  await dispatch(0);
}
const newTask = () => { taskId = 't' + Date.now() + Math.random().toString(36).slice(2, 7); raw = ''; };
async function dispatch(limit) { // limit 0 = whole conversation (no message cap); >0 = only the latest N messages
  const recent = (limit ? hist.slice(-limit) : hist).map((m) => ({ ...m }));
  if (lastImages.length) recent[recent.length - 1].content = [{ type: 'text', text: recent[recent.length - 1].content }, ...lastImages.map((a) => ({ type: 'image_url', image_url: { url: a.dataUrl } }))];
  const r = await window.altrex.send({ taskId, messages: [{ role: 'system', content: SYS + BUILD_RULES }, { role: 'system', content: curMode === 'build' ? SYS_BUILD : SYS_CODE }, ...recent] });
  if (r && r.error) { cur.textContent = r.error.message; cur.classList.add('err'); hist.pop(); finish(); }
}
async function makeImage(prompt) {
  const m = prompt.match(/\b(\d{1,2})\s+(?:different\s+)?(?:images?|pictures?|photos?|variations?)\b/i);
  const r = await window.altrex.generateImage({ taskId, prompt, count: m ? +m[1] : 1 });
  if (r.error) { cur.textContent = r.error.message; cur.classList.add('err'); finish(); return; }
  route = { provider: r.provider, model: r.model }; badge(); cur.textContent = 'Here you go.';
  r.files.forEach((f) => { if (f.preview) { const im = el('img'); im.src = f.preview; im.alt = f.name; im.style.cssText = 'max-width:100%;max-height:360px;border-radius:10px;display:block;margin-top:8px'; cur.appendChild(im); }
    const c = el('div', 'file'); c.append(el('span', 'nm', f.name)); const o = el('button', 'pri', 'Open'); o.onclick = () => window.altrex.openPath(f.path); const sh = el('button', '', 'Show in folder'); sh.onclick = () => window.altrex.revealPath(f.path); c.append(o, sh, el('div', 'pth', f.path)); cur.appendChild(c); });
  hist.push({ role: 'user', content: prompt }, { role: 'assistant', content: '(generated ' + r.files.length + ' image(s))' });
  finish();
}
function finish() { busy = false; $('#send').disabled = false; $('#stop').hidden = true; }
const shown = (text) => (curMode === 'build' ? stripCode(text) : text);
let raw = '';
window.altrex.onEvent(async (ev) => {
  if (ev.taskId !== taskId) return;
  if (ev.type === 'route') { route = ev; badge(); if (ev.fallback) addMsg('sys', 'Switched to ' + ev.provider + ' • ' + ev.model); }
  else if (ev.type === 'delta') { if (!raw) cur.textContent = ''; raw += ev.text; cur.textContent = shown(raw) || 'Working…'; $('#thread').scrollTop = 1e9; }
  else if (ev.type === 'reset') { raw = ''; cur.textContent = 'Thinking…'; }
  else if (ev.type === 'fallback') addMsg('sys', ev.from + ' failed (' + ev.reason + '). Trying another provider.');
  else if (ev.type === 'done') {
    const full = raw; raw = ''; hist.push({ role: 'assistant', content: full }); cur.textContent = shown(full);
    if (curMode === 'build') { if (!(await fileCards(cur, full))) cur.textContent = full; } else downloads(cur, full);
    finish();
  }
  else if (ev.type === 'cancelled') { cur.textContent = raw ? shown(raw) + '\n[stopped]' : 'Stopped.'; raw = ''; hist.pop(); finish(); }
  else if (ev.type === 'error' && ev.code === 'TOO_LARGE' && !trimmed && hist.length > 2) { trimmed = true; raw = ''; addMsg('sys', 'The conversation is too large for this model. Retrying with the most recent messages only.'); cur.remove(); cur = addMsg('', 'Thinking…'); newTask(); await dispatch(6); }
  else if (ev.type === 'error') { raw = ''; cur.textContent = ev.message + (ev.retryAfter ? ' Try again in ' + ev.retryAfter + 's.' : '') + (curHadImages && ev.code === 'BAD_REQUEST' ? ' This model may not accept images; pick a vision model in Settings.' : ''); cur.classList.add('err'); hist.pop(); finish(); }
});

/* settings */
async function refreshState(next) { if (next && next.error) { return next; } if (next) state = next; else state = await window.altrex.getState(); return null; }
function note(host, text, bad) { let n = host.querySelector('.note'); if (!n) { n = el('div', 'sub note'); host.appendChild(n); } n.textContent = text; n.style.color = bad ? 'var(--bad)' : ''; }
function connectForm(card, id, withUrl) {
  const form = el('div'); let name, url;
  if (withUrl) { name = el('input'); name.type = 'text'; name.placeholder = 'Name (optional)'; name.setAttribute('aria-label', 'Provider name'); url = el('input'); url.type = 'text'; url.placeholder = 'Base URL, e.g. https://host/v1'; url.setAttribute('aria-label', 'Base URL'); form.append(name, url); }
  const key = el('input'); key.type = 'password'; key.autocomplete = 'off'; key.placeholder = 'API key'; key.setAttribute('aria-label', 'API key');
  const go = el('button', 'pri', 'Connect');
  go.onclick = async () => {
    go.disabled = true; note(card, 'Connecting…');
    const r = await window.altrex.connect({ id, name: name && name.value, baseUrl: url && url.value, key: key.value }); key.value = '';
    go.disabled = false; if (r.error) { note(card, r.error.message, true); return; }
    state = r; renderSettings();
  };
  form.append(key, go); card.appendChild(form);
}
function providerCard(id, title, desc, withUrl) {
  const p = state.providers.find((x) => x.id === id), card = el('div', 'card'); card.appendChild(el('h4', '', title));
  if (!p || !p.connected) {
    card.appendChild(el('div', 'sub', desc));
    if (id === 'crax') { const o = el('button', '', 'Open crax-gpt'); o.onclick = () => window.altrex.openCrax(); o.style.margin = '8px 0'; card.append(o, el('div', 'sub', 'Sign in and create an API key, then paste it below.')); }
    connectForm(card, id, withUrl); return card;
  }
  card.appendChild(el('div', 'sub', '● Connected · ' + p.models.length + ' models · API key stored securely'));
  const sel = el('select'); sel.setAttribute('aria-label', 'Model');
  p.models.forEach((m) => { const o = el('option', '', m.name); o.value = m.id; if (m.id === p.model) o.selected = true; sel.appendChild(o); });
  sel.onchange = async () => { state = await window.altrex.select({ id, model: sel.value }); renderSettings(); };
  const use = el('button', '', state.active === id ? 'Active provider' : 'Use this provider'); use.disabled = state.active === id;
  use.onclick = async () => { state = await window.altrex.select({ id, model: p.model }); renderSettings(); };
  const rf = el('button', '', 'Refresh models'); rf.onclick = async () => { note(card, 'Refreshing…'); const r = await window.altrex.refresh(id); if (r.error) { note(card, r.error.message, true); return; } state = r; renderSettings(); };
  const dc = el('button', '', 'Disconnect'); dc.onclick = async () => { state = await window.altrex.disconnect(id); renderSettings(); };
  const row = el('div', 'row'); row.append(use, rf, dc); card.append(sel, row); return card;
}
function renderSettings() {
  const b = $('#sbody'); b.innerHTML = '';
  b.appendChild(el('h3', '', 'Privacy'));
  const lab = el('label', 'row'); const cb = el('input'); cb.type = 'checkbox'; cb.checked = state.consent;
  cb.onchange = async () => { state = await window.altrex.setConsent(cb.checked); };
  lab.append(cb, el('span', '', 'Allow sending my messages and attached code to cloud AI providers')); b.appendChild(lab);
  b.appendChild(el('h3', '', 'AI providers'));
  b.appendChild(providerCard('crax', 'crax-gpt', 'OpenAI-compatible AI gateway. Models are discovered automatically.', false));
  b.appendChild(providerCard('custom', 'Custom OpenAI-compatible', 'Any server that offers /v1/models and /v1/chat/completions (a tunnel URL counts too).', true));
}
$('#gear').onclick = async () => { await refreshState(); renderSettings(); $('#settings').showModal(); };
$('#close').onclick = () => $('#settings').close();
$('#badge').onclick = () => $('#gear').click();

$('#newchat').onclick = () => { if (busy) return; hist.length = 0; atts.length = 0; chips(); $('#chat').innerHTML = '<div class="hello" id="hello"><h1>What should we build?</h1><p>New chat started.</p></div>'; };
$('#send').onclick = send; $('#stop').onclick = () => window.altrex.cancel(taskId);
$('#attach').onclick = () => $('#fileIn').click();
$('#fileIn').onchange = (e) => { const f = [...e.target.files]; e.target.value = ''; addFiles(f); };
$('#cmd').addEventListener('input', grow);
$('#cmd').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
$('#cmd').addEventListener('paste', (e) => { const f = [...((e.clipboardData && e.clipboardData.files) || [])]; if (f.length) { e.preventDefault(); addFiles(f); } });
const dropBox = $('.box');
['dragenter', 'dragover'].forEach((n) => dropBox.addEventListener(n, (e) => { e.preventDefault(); dropBox.classList.add('drag'); }));
['dragleave', 'drop'].forEach((n) => dropBox.addEventListener(n, (e) => { e.preventDefault(); dropBox.classList.remove('drag'); }));
dropBox.addEventListener('drop', (e) => addFiles([...(e.dataTransfer.files || [])]));
document.addEventListener('dragover', (e) => e.preventDefault()); document.addEventListener('drop', (e) => e.preventDefault());
refreshState().then(badge);

/* ---- build + approval ---- */
function buildCard(host, dir) {
  const c = el('div', 'file'); c.append(el('span', 'nm', 'Build the .exe'));
  const b = el('button', 'pri', 'Review & build'); b.onclick = () => reviewBuild(dir, host); c.append(b, el('div', 'pth', 'Nothing runs until you review and approve the build script.')); host.appendChild(c);
}
async function reviewBuild(dir, host) {
  const p = await window.altrex.buildPreview(dir); if (p.error) { addMsg('sys', p.error.message); return; }
  const d = $('#approve'), body = $('#aBody'); body.innerHTML = '';
  const head = el('div'); head.append(el('span', 'risk r-' + p.risk, p.risk === 'FORBIDDEN' ? 'BLOCKED' : p.risk + ' RISK'), el('span', 'sub', '  ' + p.file + ' in ' + p.dir)); body.appendChild(head);
  const ul = el('ul'); p.reasons.forEach((r) => ul.appendChild(el('li', '', r))); body.appendChild(ul);
  body.appendChild(el('div', 'sub', 'This script will run on your PC with your permissions. Read it first:')); body.appendChild(el('pre', 'script', p.text));
  const row = el('div', 'row'); let ok = null;
  if (p.risk === 'FORBIDDEN') body.appendChild(el('div', 'msg err', 'ALTREX will not run this script. Ask it to rewrite the build without these things.'));
  else if (p.risk === 'HIGH') { const lab = el('label', 'row'); ok = el('input'); ok.type = 'checkbox'; lab.append(ok, el('span', '', 'I have read this script and trust it')); body.appendChild(lab); }
  const cancel = el('button', '', p.risk === 'FORBIDDEN' ? 'Close' : 'Cancel'); cancel.onclick = () => d.close(); row.appendChild(cancel);
  if (p.risk !== 'FORBIDDEN') { const run = el('button', 'pri', 'Run build'); if (ok) { run.disabled = true; ok.onchange = () => { run.disabled = !ok.checked; }; }
    run.onclick = async () => { d.close(); const r = await window.altrex.buildRun(p.token); if (r.error) { addMsg('sys', r.error.message); return; } showRun(host, r.runId); }; row.appendChild(run); }
  body.appendChild(row); d.showModal();
}
const runViews = new Map();
function showRun(host, runId) {
  const out = el('pre', 'out', 'Building…\n'), bar = el('div', 'row'); bar.style.marginTop = '8px';
  const stop = el('button', '', 'Stop build'); stop.onclick = () => window.altrex.buildCancel(runId); bar.appendChild(stop); host.append(out, bar);
  runViews.set(runId, { out, bar, stop, host, text: '' }); $('#thread').scrollTop = 1e9;
}
window.altrex.onCommand((ev) => {
  const v = runViews.get(ev.runId); if (!v) return;
  if (ev.type === 'output') { v.text += ev.text; if (v.text.length > 200000) v.text = v.text.slice(-150000); v.out.textContent = v.text; v.out.scrollTop = 1e9; return; }
  v.stop.remove(); runViews.delete(ev.runId);
  const msg = ev.cancelled ? 'Build stopped.' : ev.timedOut ? 'Build timed out and was stopped.' : ev.error ? 'Could not start the build: ' + ev.error : ev.code === 0 ? (ev.exes.length ? 'Build finished. Your .exe:' : 'Build finished, but no new .exe was found.') : 'Build failed (exit code ' + ev.code + ').';
  v.bar.appendChild(el('span', ev.code === 0 ? 'sub' : 'msg err', msg));
  (ev.exes || []).forEach((x) => { const c = el('div', 'file'); c.append(el('span', 'nm', x.name)); const rev = el('button', 'pri', 'Show in folder'); rev.onclick = () => window.altrex.revealPath(x.path); c.append(rev, el('div', 'pth', x.path)); v.host.appendChild(c); });
  if (ev.code !== 0 && !ev.cancelled) { const fix = el('button', '', 'Send errors to ALTREX to fix'); fix.onclick = () => { nextMode = 'build'; $('#cmd').value = 'The build failed. Fix the project and make the updated project files. Build output (last lines):\n' + v.text.split('\n').slice(-40).join('\n'); grow(); $('#cmd').focus(); }; v.bar.appendChild(fix); }
});
