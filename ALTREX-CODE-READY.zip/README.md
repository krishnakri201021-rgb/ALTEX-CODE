# ALTREX CODE

Desktop AI coding chat. Connect crax-gpt (https://gpt.crax.lol/v1) or any OpenAI-compatible server; models are discovered from `/v1/models`.

## Run (needs Node.js 20+)
    npm install
    npm start

## Tests (no network, no API key needed)
    npm test

## Build Windows installer + portable exe
    npm run dist
Output is in `dist/`.

## Security
- API keys are encrypted with the OS keystore and never sent to the UI.
- Cloud-consent is enforced in the main process before any request.
- Fallback: on 429/5xx/timeout/offline the next connected provider is used; a bad key is not retried.

## Not included yet
Tool calling, image attachments, file/terminal tools, the multi-agent loop. Live crax-gpt testing needs your own API key.

## Files and images
- Attach text/code files and PNG/JPEG/GIF/WebP images (button, paste, or drag and drop). Images need a vision-capable model.
- When you ask ALTREX to make something (e.g. "make a webpage"), the files are saved to Documents\ALTREX Projects\<timestamp>\ and shown as Open / Show in folder cards, with no code in the chat. Ask for "the code" to see it in the chat.

## Limits and what ALTREX can make
- Attach up to 200 items at once (up to 60 images, large photos are shrunk automatically). The app puts no cap on the number of messages; the AI provider's own context and rate limits still apply. If a provider says the request is too large, ALTREX retries with the most recent messages.
- Webpages, SVG images, scripts, documents and any text-based project: saved as files you can open.
- AI images (PNG/JPG): needs a connected provider that lists an image model (via /v1/images/generations). Not verified against crax-gpt.
- Video: not supported unless a video provider is added. ALTREX makes animated HTML/SVG instead.
- .exe: ALTREX writes the source plus build.bat and shows a **Review & build** button. You see the script, its risk level (MEDIUM / HIGH / BLOCKED) and the reasons, and nothing runs until you approve. Output streams live, Stop kills the whole process tree, and the finished .exe is shown with Show in folder. Needs the build tool (e.g. Python + PyInstaller) installed on your PC. Windows only.
- Safety: scripts that touch system settings, the registry, drives/paths outside their own folder, `..`, user folders, encoded PowerShell, or download-and-run are BLOCKED. Scripts that run unknown programs are HIGH and need a confirmation tick. This is a check, not a sandbox: only approve scripts you have read. ALTREX never opens .bat/.exe/.js/.ps1 files from a button.


## Build on GitHub Actions

Push these files to the `main` branch of your repository. The workflow at
`.github/workflows/main.yml` runs `npm install`, `npm test`, and `npm run dist`
on a Windows runner. When it succeeds, download the `ALTREX-CODE-Windows`
artifact from the Actions run. It contains the installer and portable EXE.
