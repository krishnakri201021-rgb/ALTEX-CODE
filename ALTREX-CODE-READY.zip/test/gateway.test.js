'use strict';
const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const { listModels, chatStream } = require('../src/gateway');
const { runChat } = require('../src/router');

function server(handler) {
  const reqs = [];
  const s = http.createServer((req, res) => { reqs.push(req); handler(req, res); });
  return new Promise((r) => s.listen(0, '127.0.0.1', () => r({ s, reqs, base: 'http://127.0.0.1:' + s.address().port + '/v1' })));
}
const sse = (res, parts) => { res.writeHead(200, { 'Content-Type': 'text/event-stream' }); for (const p of parts) res.write(p); res.end(); };
const chunk = (t) => 'data: ' + JSON.stringify({ choices: [{ delta: { content: t } }] }) + '\n\n';
const okStream = (res) => sse(res, [chunk('Hel'), chunk('lo'), 'data: [DONE]\n\n']);
const msgs = [{ role: 'user', content: 'hi' }];

test('listModels parses the dynamic catalog and sends bearer auth', async () => {
  const { s, reqs, base } = await server((req, res) => res.end(JSON.stringify({ data: [{ id: 'm1', context_length: 1000 }, { id: 'm2' }] })));
  const m = await listModels(base, 'k'); s.close();
  assert.deepStrictEqual(m.map((x) => x.id), ['m1', 'm2']); assert.strictEqual(m[0].contextLength, 1000);
  assert.strictEqual(reqs[0].headers.authorization, 'Bearer k'); assert.strictEqual(reqs[0].url, '/v1/models');
});
test('401 -> AUTH_ERROR, 404 -> MODEL_NOT_FOUND, 500 -> PROVIDER_ERROR, 413 -> TOO_LARGE', async () => {
  for (const [status, code] of [[401, 'AUTH_ERROR'], [404, 'MODEL_NOT_FOUND'], [500, 'PROVIDER_ERROR'], [503, 'PROVIDER_ERROR'], [413, 'TOO_LARGE']]) {
    const { s, base } = await server((q, r) => { r.statusCode = status; r.end('{}'); });
    await assert.rejects(listModels(base, 'k'), (e) => e.code === code); s.close();
  }
});
test('429 -> RATE_LIMITED with Retry-After', async () => {
  const { s, base } = await server((q, r) => { r.writeHead(429, { 'Retry-After': '7' }); r.end(); });
  await assert.rejects(chatStream({ baseUrl: base, key: 'k', model: 'm', messages: msgs }), (e) => e.code === 'RATE_LIMITED' && e.retryAfter === 7); s.close();
});
test('malformed /models body -> MALFORMED_RESPONSE', async () => {
  const { s, base } = await server((q, r) => r.end('not json')); await assert.rejects(listModels(base, 'k'), (e) => e.code === 'MALFORMED_RESPONSE'); s.close();
});
test('unreachable server -> OFFLINE', async () => {
  await assert.rejects(listModels('http://127.0.0.1:1/v1', 'k'), (e) => e.code === 'OFFLINE');
});
test('streaming assembles text split mid-line across chunks', async () => {
  const full = chunk('Hel') + chunk('lo') + 'data: [DONE]\n\n';
  const { s, base } = await server((q, r) => sse(r, [full.slice(0, 20), full.slice(20, 55), full.slice(55)]));
  const got = []; const r = await chatStream({ baseUrl: base, key: 'k', model: 'm', messages: msgs, onDelta: (d) => got.push(d) }); s.close();
  assert.strictEqual(r.text, 'Hello'); assert.strictEqual(got.join(''), 'Hello');
});
test('malformed stream JSON -> MALFORMED_STREAM', async () => {
  const { s, base } = await server((q, r) => sse(r, ['data: {oops\n\n']));
  await assert.rejects(chatStream({ baseUrl: base, key: 'k', model: 'm', messages: msgs }), (e) => e.code === 'MALFORMED_STREAM'); s.close();
});
test('stream idle timeout -> TIMEOUT', async () => {
  const { s, base } = await server((q, r) => { r.writeHead(200, { 'Content-Type': 'text/event-stream' }); r.write(chunk('a')); });
  await assert.rejects(chatStream({ baseUrl: base, key: 'k', model: 'm', messages: msgs, idleMs: 100 }), (e) => e.code === 'TIMEOUT');
  s.closeAllConnections(); s.close();
});
test('cancellation mid-stream -> CANCELLED', async () => {
  const { s, base } = await server((q, r) => { r.writeHead(200, { 'Content-Type': 'text/event-stream' }); r.write(chunk('a')); });
  const ctl = new AbortController();
  const p = chatStream({ baseUrl: base, key: 'k', model: 'm', messages: msgs, signal: ctl.signal, onDelta: () => ctl.abort() });
  await assert.rejects(p, (e) => e.code === 'CANCELLED'); s.closeAllConnections(); s.close();
});
test('consent missing: blocked and NO request reaches any provider', async () => {
  const { s, reqs, base } = await server((q, r) => okStream(r)); const ev = [];
  const r = await runChat({ consent: false, candidates: [{ id: 'a', name: 'A', baseUrl: base, model: 'm' }], messages: msgs, emit: (e) => ev.push(e), getKey: () => 'k' }); s.close();
  assert.strictEqual(r.code, 'CONSENT_REQUIRED'); assert.strictEqual(reqs.length, 0); assert.strictEqual(ev[0].code, 'CONSENT_REQUIRED');
});
test('consent granted: streams and reports the real route', async () => {
  const { s, base } = await server((q, r) => okStream(r)); const ev = [];
  const r = await runChat({ consent: true, candidates: [{ id: 'a', name: 'A', baseUrl: base, model: 'm1' }], messages: msgs, emit: (e) => ev.push(e), getKey: () => 'k' }); s.close();
  assert.ok(r.ok); assert.strictEqual(r.text, 'Hello'); assert.deepStrictEqual(ev[0], { type: 'route', provider: 'A', model: 'm1', fallback: false });
});
test('429 on first provider falls back to the second; route events reflect it', async () => {
  const a = await server((q, r) => { r.writeHead(429); r.end(); }); const b = await server((q, r) => okStream(r)); const ev = [];
  const r = await runChat({ consent: true, messages: msgs, emit: (e) => ev.push(e), getKey: () => 'k',
    candidates: [{ id: 'a', name: 'A', baseUrl: a.base, model: 'x' }, { id: 'b', name: 'B', baseUrl: b.base, model: 'y' }] }); a.s.close(); b.s.close();
  assert.ok(r.ok); assert.deepStrictEqual(ev.filter((e) => e.type === 'route').map((e) => e.provider + ':' + e.fallback), ['A:false', 'B:true']);
  assert.ok(ev.some((e) => e.type === 'fallback' && e.reason === 'RATE_LIMITED'));
});
test('401 does NOT fall back (bad key is not retryable)', async () => {
  const a = await server((q, r) => { r.writeHead(401); r.end(); }); const b = await server((q, r) => okStream(r)); const ev = [];
  const r = await runChat({ consent: true, messages: msgs, emit: (e) => ev.push(e), getKey: () => 'k',
    candidates: [{ id: 'a', name: 'A', baseUrl: a.base, model: 'x' }, { id: 'b', name: 'B', baseUrl: b.base, model: 'y' }] }); a.s.close(); b.s.close();
  assert.strictEqual(r.code, 'AUTH_ERROR'); assert.strictEqual(b.reqs.length, 0);
});
test('no providers -> NO_PROVIDER', async () => {
  const r = await runChat({ consent: true, candidates: [], messages: msgs, emit: () => {}, getKey: () => 'k' }); assert.strictEqual(r.code, 'NO_PROVIDER');
});
