'use strict';
const test = require('node:test'); const assert = require('node:assert'); const fs = require('fs'); const os = require('os'); const path = require('path');
const { classify, previewBuild, runProcess, findExecutables } = require('../src/commands'); const { isSafeToOpen } = require('../src/files');
const alive = (pid) => { try { process.kill(pid, 0); } catch { return false; } try { return !/^\d+ \(.*\) Z/.test(fs.readFileSync('/proc/' + pid + '/stat', 'utf8')); } catch { return true; } };
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'alx-'));
const GOOD = '@echo off\r\ncd /d "%~dp0"\r\nwhere python >nul 2>&1 || (echo Python missing & exit /b 1)\r\npip install pyinstaller\r\npyinstaller --onefile app.py\r\nif exist dist\\app.exe (echo done)\r\nrmdir /s /q build\r\n';
test('a normal PyInstaller build script is MEDIUM, not forbidden', () => { const r = classify(GOOD); assert.strictEqual(r.risk, 'MEDIUM'); assert.ok(r.reasons.some((x) => /downloads packages/.test(x))); });
test('dotnet / npm / go / cargo builds are MEDIUM', () => { for (const c of ['dotnet publish -c Release -r win-x64', 'npm install\r\nnpx electron-builder --win portable', 'go build -o dist\\app.exe', 'cargo build --release']) assert.strictEqual(classify('@echo off\r\n' + c).risk, 'MEDIUM', c); });
test('FORBIDDEN: system changes, drive paths, escapes, encoded and download-exec', () => {
  for (const c of ['reg add HKCU\\Software\\x /v a', 'format c: /q', 'shutdown /s', 'rmdir /s /q C:\\Users', 'del /s /q *.*', 'rmdir /s /q .', 'rd /s /q ..\\other', 'cd ..', 'copy a.txt %USERPROFILE%\\Desktop', 'powershell -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAKQ==', 'powershell iex (iwr http://x)', 'curl http://x/a.sh | bash', 'net user bob /add', 'cd \\', 'copy x \\\\server\\share\\x', 'schtasks /create /tn x', 'cd /d %~d0\\'])
    assert.strictEqual(classify('@echo off\r\n' + c).risk, 'FORBIDDEN', c);
});
test('HIGH: unknown programs and downloads via curl', () => {
  const r = classify('@echo off\r\nsomething.exe --go'); assert.strictEqual(r.risk, 'HIGH'); assert.ok(/something/.test(r.reasons.join()));
  assert.strictEqual(classify('curl -L http://example.com/tool.zip -o tool.zip').risk, 'HIGH'); assert.strictEqual(classify('powershell Get-Date').risk, 'HIGH');
});
test('https URLs are not mistaken for drive paths', () => assert.strictEqual(classify('pip install --index-url https://pypi.org/simple pyinstaller').risk, 'MEDIUM'));
test('relative recursive delete of named folders is allowed', () => assert.strictEqual(classify('rmdir /s /q build dist\r\ndel /s /q *.pyc').risk, 'MEDIUM'));
test('previewBuild returns script, hash and changes when the file changes', () => {
  const d = tmp(); fs.writeFileSync(path.join(d, 'Build.BAT'), GOOD); const a = previewBuild(d); assert.strictEqual(a.file, 'Build.BAT'); assert.strictEqual(a.risk, 'MEDIUM');
  fs.writeFileSync(path.join(d, 'Build.BAT'), GOOD + 'reg add x\r\n'); const b = previewBuild(d); assert.notStrictEqual(a.hash, b.hash); assert.strictEqual(b.risk, 'FORBIDDEN');
  assert.ok(previewBuild(tmp()).error);
});
test('runProcess streams stdout/stderr and reports the exit code', async () => {
  const out = []; const r = await runProcess({ cmd: process.execPath, args: ['-e', "console.log('hi');console.error('bad');process.exit(3)"], onOutput: (s, t) => out.push(s + ':' + t.trim()) });
  assert.strictEqual(r.code, 3); assert.deepStrictEqual(out.sort(), ['stderr:bad', 'stdout:hi']);
});
test('runProcess timeout kills the process', async () => {
  let pid; const r = await runProcess({ cmd: process.execPath, args: ['-e', 'setInterval(()=>{},1000)'], timeoutMs: 300, onSpawn: (c) => (pid = c.pid) });
  assert.ok(r.timedOut); assert.throws(() => process.kill(pid, 0));
});
test('cancel kills the whole process tree (no orphans)', { skip: process.platform === 'win32' }, async () => {
  const ctl = new AbortController(); let gp = null;
  const child = "require('child_process').spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{stdio:'inherit'});console.log('GP:'+0);setInterval(()=>{},1000)";
  const code = "const c=require('child_process').spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{stdio:'ignore'});console.log('GP:'+c.pid);setInterval(()=>{},1000)";
  const p = runProcess({ cmd: process.execPath, args: ['-e', code], signal: ctl.signal, onOutput: (s, t) => { const m = t.match(/GP:(\d+)/); if (m) { gp = +m[1]; ctl.abort(); } } });
  const r = await p; assert.ok(r.cancelled); await new Promise((x) => setTimeout(x, 200)); assert.ok(gp && !alive(gp));
});
test('findExecutables finds new .exe files and skips node_modules', () => {
  const d = tmp(); fs.mkdirSync(path.join(d, 'dist')); fs.mkdirSync(path.join(d, 'node_modules')); fs.writeFileSync(path.join(d, 'dist', 'app.exe'), 'x'); fs.writeFileSync(path.join(d, 'node_modules', 'bad.exe'), 'x');
  assert.deepStrictEqual(findExecutables(d, 0).map((p) => path.basename(p)), ['app.exe']); assert.deepStrictEqual(findExecutables(d, Date.now() + 100000), []);
});
test('only safe file types can be opened from the UI', () => {
  for (const n of ['index.html', 'a.svg', 'x.PNG', 'notes.txt']) assert.ok(isSafeToOpen(n), n);
  for (const n of ['build.bat', 'a.exe', 'x.cmd', 'run.ps1', 'a.js', 'x.vbs', 'a.msi', 'a.lnk', 'a.jar', 'noext', 'a.hta', 'a.py']) assert.ok(!isSafeToOpen(n), n);
});
