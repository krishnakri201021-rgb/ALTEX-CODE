'use strict';
const test = require('node:test'); const assert = require('node:assert'); const fs = require('fs'); const os = require('os'); const path = require('path');
const { Store } = require('../src/store');
const fake = { isAvailable: () => true, encrypt: (s) => Buffer.from('ENC:' + s), decrypt: (b) => b.toString().slice(4) };
test('keys are encrypted at rest and never appear in the renderer view', () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'alx-')), 'a.json'); const st = new Store(f, fake);
  st.data.providers.crax = { name: 'crax-gpt', baseUrl: 'u', models: [], model: 'm' }; st.setKey('crax', 'SECRET-KEY-123'); st.save();
  assert.ok(!fs.readFileSync(f, 'utf8').includes('SECRET-KEY-123')); assert.ok(!JSON.stringify(st.view()).includes('SECRET-KEY-123'));
  assert.strictEqual(new Store(f, fake).getKey('crax'), 'SECRET-KEY-123');
});
test('refuses to store a key when secure storage is unavailable', () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'alx-')), 'a.json'); const st = new Store(f, { ...fake, isAvailable: () => false });
  st.data.providers.x = { name: 'x' }; assert.throws(() => st.setKey('x', 'k'));
});
