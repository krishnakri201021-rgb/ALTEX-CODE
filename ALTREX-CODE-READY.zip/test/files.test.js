'use strict';
const test = require('node:test'); const assert = require('node:assert'); const fs = require('fs'); const os = require('os'); const path = require('path');
const { safeRelPath, saveFiles } = require('../src/files');
const { intent, blocks, stripCode } = require('../renderer/intent');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'alx-'));
test('saves files into a new folder and returns real paths', () => {
  const r = saveFiles(tmp(), [{ name: 'index.html', content: '<h1>x</h1>' }, { name: 'css/a.css', content: 'b{}' }]);
  assert.strictEqual(r.files.length, 2); assert.strictEqual(fs.readFileSync(r.files[0].path, 'utf8'), '<h1>x</h1>'); assert.ok(fs.existsSync(r.files[1].path));
});
test('rejects traversal, absolute, drive and odd names', () => {
  for (const n of ['../x.js', 'a/../../x', '/etc/x', 'C:\\x.txt', 'C:/x', '..', 'a//b', 'a|b', '']) assert.strictEqual(safeRelPath(n), null, n);
  assert.throws(() => saveFiles(tmp(), [{ name: '../evil.js', content: 'x' }]));
});
test('two saves in the same second never overwrite each other', () => {
  const root = tmp(), now = new Date(); const a = saveFiles(root, [{ name: 'a.txt', content: '1' }], now), b = saveFiles(root, [{ name: 'a.txt', content: '2' }], now);
  assert.notStrictEqual(a.dir, b.dir); assert.strictEqual(fs.readFileSync(a.files[0].path, 'utf8'), '1');
});
test('intent: code is hidden by default and shown only when asked', () => {
  for (const m of ['hi', 'make a webpage for my bakery', 'build a classic wbpg of rainbow', 'make wbpg of ff redem codes', 'prototype', 'make it blue', 'just make wbpg dont write code here', 'no code', 'how do I reverse a string in python', 'create a calculator app', 'explain closures', 'make a poster webpage', 'make a wbpg with a logo'])
    assert.strictEqual(intent(m), 'build', m);
  for (const m of ['give code for a login page', 'write the code', 'give me the code', 'show code', 'make a webpage and give me the code', 'i want the source code', 'code please'])
    assert.strictEqual(intent(m), 'code', m);
});
test('blocks and stripCode handle finished and half-streamed code', () => {
  const t = 'Done.\n```html filename=index.html\n<p>hi</p>\n```\nEnjoy';
  assert.deepStrictEqual(blocks(t), [{ name: 'index.html', content: '<p>hi</p>\n' }]);
  assert.ok(!stripCode(t).includes('<p>')); assert.ok(stripCode(t).includes('Done.'));
  const half = 'Making it.\n```html filename=index.html\n<p>par'; assert.ok(!stripCode(half).includes('<p>')); assert.ok(stripCode(half).includes('writing the file'));
});
