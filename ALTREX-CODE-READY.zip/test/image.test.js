'use strict';
const test = require('node:test'); const assert = require('node:assert'); const http = require('node:http'); const fs = require('fs'); const os = require('os'); const path = require('path');
const { generateImage } = require('../src/gateway'); const { saveFiles } = require('../src/files'); const { intent } = require('../renderer/intent');
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.from('xxxxxxxx')]);
const srv = (h) => new Promise((r) => { const reqs = []; const s = http.createServer((q, res) => { let b = ''; q.on('data', (d) => (b += d)); q.on('end', () => { reqs.push({ url: q.url, body: b, auth: q.headers.authorization }); h(q, res); }); }); s.listen(0, '127.0.0.1', () => r({ s, reqs, base: 'http://127.0.0.1:' + s.address().port + '/v1' })); });
test('generateImage decodes b64 images and sends the right request', async () => {
  const { s, reqs, base } = await srv((q, r) => r.end(JSON.stringify({ data: [{ b64_json: PNG.toString('base64') }, { b64_json: PNG.toString('base64') }] })));
  const out = await generateImage({ baseUrl: base, key: 'k', model: 'img-1', prompt: 'a cat', n: 2 }); s.close();
  assert.strictEqual(out.length, 2); assert.strictEqual(out[0].ext, 'png'); assert.strictEqual(reqs[0].url, '/v1/images/generations'); assert.strictEqual(JSON.parse(reqs[0].body).n, 2); assert.strictEqual(reqs[0].auth, 'Bearer k');
});
test('generateImage rejects non-image data, empty data, and private/non-https URLs', async () => {
  for (const body of [{ data: [{ b64_json: Buffer.from('not an image at all').toString('base64') }] }, { data: [] }, { data: [{ url: 'http://example.com/a.png' }] }, { data: [{ url: 'https://127.0.0.1/a.png' }] }, { data: [{ url: 'https://192.168.1.5/a.png' }] }]) {
    const { s, base } = await srv((q, r) => r.end(JSON.stringify(body))); await assert.rejects(generateImage({ baseUrl: base, key: 'k', model: 'm', prompt: 'p' }), (e) => e.code === 'MALFORMED_RESPONSE'); s.close();
  }
});
test('generateImage maps 429 and 401', async () => {
  for (const [st, code] of [[429, 'RATE_LIMITED'], [401, 'AUTH_ERROR']]) { const { s, base } = await srv((q, r) => { r.statusCode = st; r.end(); }); await assert.rejects(generateImage({ baseUrl: base, key: 'k', model: 'm', prompt: 'p' }), (e) => e.code === code); s.close(); }
});
test('saveFiles writes binary (base64) files byte-for-byte', () => {
  const r = saveFiles(fs.mkdtempSync(path.join(os.tmpdir(), 'alx-')), [{ name: 'image-1.png', base64: PNG.toString('base64') }]);
  assert.ok(fs.readFileSync(r.files[0].path).equals(PNG));
});
test('intent: images, svg, exe, webpages', () => {
  assert.strictEqual(intent('generate an image of a red car'), 'image'); assert.strictEqual(intent('make 3 pictures of mountains'), 'image');
  assert.strictEqual(intent('make an svg logo'), 'build'); assert.strictEqual(intent('make a poster webpage'), 'build');
  assert.strictEqual(intent('create an exe program that renames files'), 'build'); assert.strictEqual(intent('draw an image and give me the code'), 'code'); assert.strictEqual(intent('make a pic of a dog'), 'image'); assert.strictEqual(intent('make an svg logo and write the code'), 'code');
});
