'use strict';
const { chatStream, describe } = require('./gateway');
const RETRYABLE = new Set(['RATE_LIMITED', 'PROVIDER_ERROR', 'OFFLINE', 'TIMEOUT']);
// Consent is enforced here, before any network request that could carry project code.
async function runChat({ consent, candidates, messages, emit, signal, getKey, opts = {} }) {
  if (!consent) { emit({ type: 'error', code: 'CONSENT_REQUIRED', message: describe('CONSENT_REQUIRED') }); return { ok: false, code: 'CONSENT_REQUIRED' }; }
  if (!candidates.length) { emit({ type: 'error', code: 'NO_PROVIDER', message: describe('NO_PROVIDER') }); return { ok: false, code: 'NO_PROVIDER' }; }
  let last;
  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i];
    emit({ type: 'route', provider: c.name, model: c.model, fallback: i > 0 });
    try {
      const r = await chatStream({ baseUrl: c.baseUrl, key: getKey(c.id), model: c.model, messages, signal, onDelta: (t) => emit({ type: 'delta', text: t }), ...opts });
      emit({ type: 'done', provider: c.name, model: c.model });
      return { ok: true, text: r.text };
    } catch (e) {
      last = e;
      if (e.code === 'CANCELLED') { emit({ type: 'cancelled' }); return { ok: false, code: 'CANCELLED' }; }
      if (!RETRYABLE.has(e.code) || i === candidates.length - 1) break;
      emit({ type: 'fallback', from: c.name, reason: e.code });
      emit({ type: 'reset' });
    }
  }
  const code = last ? last.code : 'PROVIDER_ERROR';
  emit({ type: 'error', code, message: describe(code), retryAfter: (last && last.retryAfter) || null });
  return { ok: false, code };
}
module.exports = { runChat, RETRYABLE };
