'use strict';
const { app, BrowserWindow, ipcMain, shell, safeStorage } = require('electron');
const path = require('path');
const { Store } = require('./store');
const { listModels, describe, generateImage } = require('./gateway');
const { runChat, RETRYABLE } = require('./router');
const { saveFiles, isSafeToOpen } = require('./files');
const { previewBuild, runProcess, findExecutables } = require('./commands');
const crypto = require('crypto');

const CRAX = { name: 'crax-gpt', baseUrl: 'https://gpt.crax.lol/v1' };
let win, store; const tasks = new Map(), savedPaths = new Set(), projectDirs = new Set(), approvals = new Map(), runs = new Map();

function createWindow() {
  win = new BrowserWindow({ width: 1100, height: 760, minWidth: 560, minHeight: 480, backgroundColor: '#262624',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}
app.whenReady().then(() => {
  store = new Store(path.join(app.getPath('userData'), 'altrex.json'), {
    isAvailable: () => safeStorage.isEncryptionAvailable(), encrypt: (s) => safeStorage.encryptString(s), decrypt: (b) => safeStorage.decryptString(b) });
  createWindow();
});
app.on('window-all-closed', () => { for (const c of tasks.values()) c.abort(); for (const r of runs.values()) r.abort(); app.quit(); });

const fail = (e) => ({ error: { code: e.code || 'ERROR', message: e.code ? describe(e.code) : 'Something went wrong.' } });

ipcMain.handle('state:get', () => store.view());
ipcMain.handle('consent:set', (_e, v) => { store.data.consent = v === true; store.save(); return store.view(); });
ipcMain.handle('open:crax', () => shell.openExternal('https://gpt.crax.lol'));
ipcMain.handle('provider:connect', async (_e, { id, name, baseUrl, key }) => {
  try {
    if (typeof key !== 'string' || !key.trim()) return { error: { code: 'AUTH_ERROR', message: describe('AUTH_ERROR') } };
    let pid = id, cfg;
    if (id === 'crax') cfg = CRAX;
    else {
      const u = new URL(baseUrl); if (!/^https?:$/.test(u.protocol)) throw new Error('Use an http(s) address.');
      pid = 'custom'; cfg = { name: (name || 'Custom').slice(0, 40), baseUrl: u.toString().replace(/\/+$/, '') };
    }
    const models = await listModels(cfg.baseUrl, key.trim());
    if (!models.length) return { error: { code: 'MODEL_NOT_FOUND', message: 'Connected, but the provider lists no models.' } };
    store.data.providers[pid] = { ...cfg, models, model: models[0].id }; store.setKey(pid, key.trim());
    if (!store.data.active) store.data.active = pid;
    store.save(); return store.view();
  } catch (e) { return e.code ? fail(e) : { error: { code: 'BAD_REQUEST', message: e.message || 'Invalid input.' } }; }
});
ipcMain.handle('provider:refresh', async (_e, id) => {
  const p = store.data.providers[id]; if (!p) return fail({});
  try {
    p.models = await listModels(p.baseUrl, store.getKey(id));
    if (!p.models.some((m) => m.id === p.model)) p.model = p.models[0] ? p.models[0].id : null;
    store.save(); return store.view();
  } catch (e) { return fail(e); }
});
ipcMain.handle('provider:disconnect', (_e, id) => { delete store.data.providers[id]; if (store.data.active === id) store.data.active = Object.keys(store.data.providers)[0] || null; store.save(); return store.view(); });
ipcMain.handle('provider:select', (_e, { id, model }) => {
  const p = store.data.providers[id]; if (!p) return store.view();
  store.data.active = id; if (p.models.some((m) => m.id === model)) p.model = model; store.save(); return store.view();
});
const validContent = (c) => typeof c === 'string' || (Array.isArray(c) && c.length <= 300 && c.every((p) => p && ((p.type === 'text' && typeof p.text === 'string') ||
  (p.type === 'image_url' && p.image_url && typeof p.image_url.url === 'string' && /^data:image\/(png|jpeg|gif|webp);base64,/.test(p.image_url.url) && p.image_url.url.length < 12e6))));
ipcMain.handle('chat:send', async (e, { taskId, messages }) => {
  if (!Array.isArray(messages) || messages.some((m) => !m || !validContent(m.content) || !['user', 'assistant', 'system'].includes(m.role))) return { error: { code: 'BAD_REQUEST', message: 'Invalid message.' } };
  const order = [store.data.active, ...Object.keys(store.data.providers).filter((k) => k !== store.data.active)];
  const candidates = order.filter((id) => store.data.providers[id] && store.data.providers[id].enc && store.data.providers[id].model)
    .map((id) => ({ id, ...store.data.providers[id] }));
  const ctl = new AbortController(); tasks.set(taskId, ctl);
  const emit = (ev) => { if (!e.sender.isDestroyed()) e.sender.send('chat:event', { taskId, ...ev }); };
  try { await runChat({ consent: store.data.consent, candidates, messages, emit, signal: ctl.signal, getKey: (id) => store.getKey(id) }); }
  finally { tasks.delete(taskId); }
  return { ok: true };
});
ipcMain.handle('chat:cancel', (_e, taskId) => { const c = tasks.get(taskId); if (c) c.abort(); });

ipcMain.handle('files:save', (_e, files) => {
  try { const r = saveFiles(path.join(app.getPath('documents'), 'ALTREX Projects'), files); r.files.forEach((f) => savedPaths.add(f.path)); savedPaths.add(r.dir); projectDirs.add(r.dir); return r; }
  catch (e) { return { error: { code: 'SAVE_FAILED', message: e.message || 'Could not save the files.' } }; }
});
ipcMain.handle('files:open', (_e, p) => { if (savedPaths.has(p) && isSafeToOpen(p)) return shell.openPath(p); if (savedPaths.has(p)) shell.showItemInFolder(p); });
ipcMain.handle('files:reveal', (_e, p) => { if (savedPaths.has(p)) shell.showItemInFolder(p); });

const IMAGE_MODEL = /(image|dall|flux|sdxl|stable|imagen|midjourney|diffusion|seedream|nano-banana)/i;
ipcMain.handle('image:generate', async (_e, { taskId, prompt, count }) => {
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 4000) return { error: { code: 'BAD_REQUEST', message: 'Invalid prompt.' } };
  if (!store.data.consent) return { error: { code: 'CONSENT_REQUIRED', message: describe('CONSENT_REQUIRED') } };
  const n = Math.min(Math.max(parseInt(count, 10) || 1, 1), 4);
  const order = [store.data.active, ...Object.keys(store.data.providers).filter((k) => k !== store.data.active)];
  const cands = order.map((id) => { const p = store.data.providers[id]; const m = p && p.enc && (p.models || []).find((x) => IMAGE_MODEL.test(x.id)); return m ? { id, ...p, imageModel: m.id } : null; }).filter(Boolean);
  if (!cands.length) return { error: { code: 'NO_IMAGE_MODEL', message: 'None of your connected providers lists an image-generation model. Connect one that does, or ask for an SVG image instead.' } };
  const ctl = new AbortController(); tasks.set(taskId, ctl); let last;
  try {
    for (const c of cands) {
      try {
        const imgs = await generateImage({ baseUrl: c.baseUrl, key: store.getKey(c.id), model: c.imageModel, prompt: prompt.trim(), n, signal: ctl.signal });
        const r = saveFiles(path.join(app.getPath('documents'), 'ALTREX Projects'), imgs.map((im, i) => ({ name: 'image-' + (i + 1) + '.' + im.ext, base64: im.base64 })));
        r.files.forEach((f) => savedPaths.add(f.path)); savedPaths.add(r.dir);
        return { provider: c.name, model: c.imageModel, dir: r.dir, files: r.files.map((f, i) => ({ ...f, preview: imgs[i].base64.length < 6e6 ? 'data:image/' + (imgs[i].ext === 'jpg' ? 'jpeg' : imgs[i].ext) + ';base64,' + imgs[i].base64 : null })) };
      } catch (e) { last = e; if (e.code === 'CANCELLED') return { error: { code: 'CANCELLED', message: 'Stopped.' } }; if (!RETRYABLE.has(e.code)) break; }
    }
    return fail(last || {});
  } finally { tasks.delete(taskId); }
});

// ---- Build step: user must review and approve the exact script before it runs ----
const bErr = (message) => ({ error: { code: 'BUILD_ERROR', message } });
ipcMain.handle('build:preview', (_e, dir) => {
  if (!projectDirs.has(dir)) return bErr('Unknown project folder.');
  const p = previewBuild(dir); if (p.error) return bErr(p.error);
  const token = crypto.randomUUID(); approvals.set(token, { dir, file: p.file, hash: p.hash, exp: Date.now() + 10 * 60000 });
  return { token, file: p.file, text: p.text, risk: p.risk, reasons: p.reasons, dir };
});
ipcMain.handle('build:run', (e, { token }) => {
  const a = approvals.get(token); approvals.delete(token); // one-time approval
  if (!a || a.exp < Date.now()) return bErr('The approval expired. Review the script again.');
  if (process.platform !== 'win32') return bErr('Running build scripts is only supported on Windows.');
  if (runs.size) return bErr('Another build is already running.');
  const p = previewBuild(a.dir);
  if (p.error || p.hash !== a.hash) return bErr('The script changed after you reviewed it. Review it again.');
  if (p.risk === 'FORBIDDEN') return bErr('ALTREX will not run this script: ' + p.reasons.join(', ') + '.');
  const runId = 'r' + Date.now(), ctl = new AbortController(), start = Date.now(); runs.set(runId, ctl);
  const send = (ev) => { if (!e.sender.isDestroyed()) e.sender.send('cmd:event', { runId, ...ev }); };
  runProcess({ cmd: 'cmd.exe', args: ['/d', '/c', a.file === p.file ? p.file : a.file], cwd: a.dir, env: process.env, signal: ctl.signal, onOutput: (stream, text) => send({ type: 'output', stream, text }) })
    .then((r) => { const exes = r.code === 0 ? findExecutables(a.dir, start - 2000).map((f) => { savedPaths.add(f); return { name: path.relative(a.dir, f), path: f }; }) : [];
      send({ type: 'exit', code: r.code, timedOut: r.timedOut, cancelled: r.cancelled, error: r.error || null, exes }); })
    .finally(() => runs.delete(runId));
  return { runId };
});
ipcMain.handle('build:cancel', (_e, runId) => { const c = runs.get(runId); if (c) c.abort(); });
