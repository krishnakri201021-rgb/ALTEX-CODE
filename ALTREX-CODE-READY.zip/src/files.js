'use strict';
const fs = require('fs'), path = require('path');
// Saves AI-generated files into a fresh folder. Names are validated so nothing can escape that folder.
function safeRelPath(name) {
  if (typeof name !== 'string') return null;
  const n = name.replace(/\\/g, '/').trim();
  if (!n || n.length > 120 || n.startsWith('/') || /^[a-zA-Z]:/.test(n) || /[<>:"|?*\u0000-\u001f]/.test(n)) return null;
  const parts = n.split('/');
  if (parts.some((p) => !p || p === '.' || p === '..' || /^\.+$/.test(p))) return null;
  return parts.join('/');
}
function saveFiles(root, files, now = new Date()) {
  if (!Array.isArray(files) || !files.length || files.length > 30) throw new Error('No files to save.');
  const stamp = now.toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
  let dir = path.join(root, stamp), i = 1; while (fs.existsSync(dir)) dir = path.join(root, stamp + '-' + (++i));
  const saved = []; let total = 0;
  for (const f of files) {
    const rel = safeRelPath(f && f.name);
    const bin = f && typeof f.base64 === 'string';
    if (!rel || (!bin && typeof f.content !== 'string')) throw new Error('Invalid file name: ' + (f && f.name));
    const data = bin ? Buffer.from(f.base64, 'base64') : Buffer.from(f.content, 'utf8');
    total += data.length; if (total > 80e6) throw new Error('Files are too large.');
    const full = path.join(dir, ...rel.split('/'));
    if (!full.startsWith(dir + path.sep)) throw new Error('Invalid path.');
    fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, data);
    saved.push({ name: rel, path: full, bytes: data.length });
  }
  return { dir, files: saved };
}
// Only these may be opened from the UI. Scripts, executables and installers are never launched from a button.
const OPENABLE = new Set(['html', 'htm', 'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'txt', 'md', 'json', 'css', 'csv', 'pdf']);
const isSafeToOpen = (name) => OPENABLE.has(String(name).split('.').pop().toLowerCase()) && String(name).includes('.');
module.exports = { safeRelPath, saveFiles, isSafeToOpen };
