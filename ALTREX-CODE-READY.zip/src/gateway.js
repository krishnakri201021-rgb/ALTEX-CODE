'use strict';
// Normalized OpenAI-compatible gateway. All provider HTTP/SSE details stay in this file.
class GatewayError extends Error {
  constructor(code, message, extra = {}) { super(message); this.code = code; Object.assign(this, extra); }
}
const MESSAGES = {
  AUTH_ERROR: 'The API key was rejected. Check the key and try again.',
  MODEL_NOT_FOUND: 'The provider could not find that model or endpoint. Refresh the model list.',
  BAD_REQUEST: 'The provider rejected the request as invalid.',
  RATE_LIMITED: 'The provider is rate limiting requests.',
  TOO_LARGE: 'The request is too large for this model.',
  PROVIDER_ERROR: 'The provider had a temporary failure.',
  OFFLINE: 'Could not reach the provider. Check your connection and the address.',
  TIMEOUT: 'The provider took too long to respond.',
  MALFORMED_STREAM: 'The provider sent a response ALTREX could not understand.',
  MALFORMED_RESPONSE: 'The provider sent a response ALTREX could not understand.',
  CANCELLED: 'Cancelled.',
  CONSENT_REQUIRED: 'Allow sending your messages and attached code to cloud AI providers first (Settings).',
  NO_PROVIDER: 'No AI provider is connected. Open Settings and connect one.'
};
const describe = (code) => MESSAGES[code] || 'Something went wrong.';
const url = (base, path) => base.replace(/\/+$/, '') + path;
const headers = (key, json) => ({ Authorization: 'Bearer ' + key, ...(json ? { 'Content-Type': 'application/json' } : {}) });

function httpError(res) {
  const s = res.status;
  const ra = parseFloat(res.headers.get('retry-after'));
  if (s === 401 || s === 403) return new GatewayError('AUTH_ERROR', describe('AUTH_ERROR'), { status: s });
  if (s === 404) return new GatewayError('MODEL_NOT_FOUND', describe('MODEL_NOT_FOUND'), { status: s });
  if (s === 408) return new GatewayError('TIMEOUT', describe('TIMEOUT'), { status: s });
  if (s === 413) return new GatewayError('TOO_LARGE', describe('TOO_LARGE'), { status: s });
  if (s === 429) return new GatewayError('RATE_LIMITED', describe('RATE_LIMITED'), { status: s, retryAfter: Number.isFinite(ra) ? ra : null });
  if (s >= 500) return new GatewayError('PROVIDER_ERROR', describe('PROVIDER_ERROR'), { status: s });
  return new GatewayError('BAD_REQUEST', describe('BAD_REQUEST'), { status: s });
}
function netError(e, signal, timedOut) {
  if (signal && signal.aborted) return new GatewayError('CANCELLED', describe('CANCELLED'));
  if (timedOut) return new GatewayError('TIMEOUT', describe('TIMEOUT'));
  return new GatewayError('OFFLINE', describe('OFFLINE'));
}

async function listModels(baseUrl, key, { signal, timeoutMs = 15000 } = {}) {
  const ctl = new AbortController(); let timedOut = false;
  const t = setTimeout(() => { timedOut = true; ctl.abort(); }, timeoutMs);
  const onAbort = () => ctl.abort();
  if (signal) signal.addEventListener('abort', onAbort, { once: true });
  try {
    let res;
    try { res = await fetch(url(baseUrl, '/models'), { headers: headers(key), signal: ctl.signal }); }
    catch (e) { throw netError(e, signal, timedOut); }
    if (!res.ok) throw httpError(res);
    let j; try { j = await res.json(); } catch { throw new GatewayError('MALFORMED_RESPONSE', describe('MALFORMED_RESPONSE')); }
    if (!j || !Array.isArray(j.data)) throw new GatewayError('MALFORMED_RESPONSE', describe('MALFORMED_RESPONSE'));
    return j.data.filter((m) => m && typeof m.id === 'string').map((m) => ({ id: m.id, name: m.name || m.id, contextLength: m.context_length || null }));
  } finally { clearTimeout(t); if (signal) signal.removeEventListener('abort', onAbort); }
}

async function chatStream({ baseUrl, key, model, messages, signal, onDelta, firstTokenMs = 60000, idleMs = 60000 }) {
  const ctl = new AbortController(); let timedOut = false, timer;
  const arm = (ms) => { clearTimeout(timer); timer = setTimeout(() => { timedOut = true; ctl.abort(); }, ms); };
  const onAbort = () => ctl.abort();
  if (signal) { if (signal.aborted) throw new GatewayError('CANCELLED', describe('CANCELLED')); signal.addEventListener('abort', onAbort, { once: true }); }
  arm(firstTokenMs);
  try {
    let res;
    try { res = await fetch(url(baseUrl, '/chat/completions'), { method: 'POST', headers: headers(key, true), body: JSON.stringify({ model, messages, stream: true }), signal: ctl.signal }); }
    catch (e) { throw netError(e, signal, timedOut); }
    if (!res.ok) throw httpError(res);
    const reader = res.body.getReader(); const dec = new TextDecoder();
    let buf = '', text = '', done = false;
    try {
      while (!done) {
        const { value, done: d } = await reader.read();
        if (d) break;
        arm(idleMs);
        buf += dec.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, nl).trim(); buf = buf.slice(nl + 1);
          if (!line.startsWith('data:')) continue;
          const p = line.slice(5).trim();
          if (p === '[DONE]') { done = true; break; }
          let j; try { j = JSON.parse(p); } catch { throw new GatewayError('MALFORMED_STREAM', describe('MALFORMED_STREAM')); }
          if (j && j.error) throw new GatewayError('PROVIDER_ERROR', describe('PROVIDER_ERROR'));
          const delta = j && j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content;
          if (delta) { text += delta; if (onDelta) onDelta(delta); }
        }
      }
    } catch (e) { if (e instanceof GatewayError) throw e; throw netError(e, signal, timedOut); }
    if (!text) throw new GatewayError('MALFORMED_STREAM', describe('MALFORMED_STREAM'));
    return { text };
  } finally { clearTimeout(timer); ctl.abort(); if (signal) signal.removeEventListener('abort', onAbort); }
}

// ---- Image generation (OpenAI-compatible POST /images/generations) ----
const PRIVATE_HOST = /^(localhost|127\.|10\.|0\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|\[?::1\]?$)/i;
function imageType(b) {
  if (b.length < 12) return null;
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  if (b[0] === 0xff && b[1] === 0xd8) return 'jpg';
  if (b.slice(0, 4).toString() === 'GIF8') return 'gif';
  if (b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') return 'webp';
  return null;
}
async function generateImage({ baseUrl, key, model, prompt, n = 1, signal, timeoutMs = 180000 }) {
  const ctl = new AbortController(); let timedOut = false;
  const t = setTimeout(() => { timedOut = true; ctl.abort(); }, timeoutMs);
  const onAbort = () => ctl.abort();
  if (signal) { if (signal.aborted) throw new GatewayError('CANCELLED', describe('CANCELLED')); signal.addEventListener('abort', onAbort, { once: true }); }
  const bad = () => new GatewayError('MALFORMED_RESPONSE', describe('MALFORMED_RESPONSE'));
  try {
    let res;
    try { res = await fetch(url(baseUrl, '/images/generations'), { method: 'POST', headers: headers(key, true), body: JSON.stringify({ model, prompt, n }), signal: ctl.signal }); }
    catch (e) { throw netError(e, signal, timedOut); }
    if (!res.ok) throw httpError(res);
    let j; try { j = await res.json(); } catch { throw bad(); }
    if (!j || !Array.isArray(j.data) || !j.data.length) throw bad();
    const out = [];
    for (const d of j.data) {
      let buf = null;
      if (d && typeof d.b64_json === 'string') buf = Buffer.from(d.b64_json, 'base64');
      else if (d && typeof d.url === 'string') {
        let u; try { u = new URL(d.url); } catch { throw bad(); }
        if (u.protocol !== 'https:' || PRIVATE_HOST.test(u.hostname)) throw bad();
        try { const r = await fetch(u, { signal: ctl.signal, redirect: 'error' }); if (!r.ok) throw bad(); buf = Buffer.from(await r.arrayBuffer()); }
        catch (e) { if (e instanceof GatewayError) throw e; throw netError(e, signal, timedOut); }
        if (buf.length > 20e6) throw bad();
      } else continue;
      const ext = imageType(buf); if (!ext) throw bad();
      out.push({ ext, base64: buf.toString('base64') });
    }
    if (!out.length) throw bad();
    return out;
  } finally { clearTimeout(t); if (signal) signal.removeEventListener('abort', onAbort); }
}
module.exports = { GatewayError, describe, listModels, chatStream, generateImage };
