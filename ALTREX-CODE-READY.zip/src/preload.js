'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('altrex', {
  getState: () => ipcRenderer.invoke('state:get'),
  setConsent: (v) => ipcRenderer.invoke('consent:set', v),
  openCrax: () => ipcRenderer.invoke('open:crax'),
  connect: (p) => ipcRenderer.invoke('provider:connect', p),
  refresh: (id) => ipcRenderer.invoke('provider:refresh', id),
  disconnect: (id) => ipcRenderer.invoke('provider:disconnect', id),
  select: (p) => ipcRenderer.invoke('provider:select', p),
  send: (p) => ipcRenderer.invoke('chat:send', p),
  saveFiles: (f) => ipcRenderer.invoke('files:save', f),
  openPath: (p) => ipcRenderer.invoke('files:open', p),
  revealPath: (p) => ipcRenderer.invoke('files:reveal', p),
  generateImage: (p) => ipcRenderer.invoke('image:generate', p),
  buildPreview: (d) => ipcRenderer.invoke('build:preview', d),
  buildRun: (t) => ipcRenderer.invoke('build:run', { token: t }),
  buildCancel: (id) => ipcRenderer.invoke('build:cancel', id),
  onCommand: (fn) => { const h = (_e, ev) => fn(ev); ipcRenderer.on('cmd:event', h); return () => ipcRenderer.removeListener('cmd:event', h); },
  cancel: (id) => ipcRenderer.invoke('chat:cancel', id),
  onEvent: (fn) => { const h = (_e, ev) => fn(ev); ipcRenderer.on('chat:event', h); return () => ipcRenderer.removeListener('chat:event', h); }
});
