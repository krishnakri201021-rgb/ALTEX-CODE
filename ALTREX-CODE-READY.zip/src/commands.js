'use strict';
// Permission-gated command running. The AI never runs commands directly: it can only write a build script,
// and the user must review and approve that exact script before anything executes.
const { spawn } = require('child_process');
const fs = require('fs'), path = require('path'), crypto = require('crypto');

// Anything matching these is refused outright (FORBIDDEN). Scanned over the whole script text.
const FORBIDDEN = [
  [/\bformat\s+[a-z]:|\b(diskpart|bcdedit|vssadmin|shutdown|takeown|icacls|cacls|schtasks|wmic|regedit|netsh|rundll32|mshta|wscript|cscript|msiexec|dism|sfc|gpupdate|runas|taskkill|tskill|setx|assoc|ftype|mklink)\b/i, 'changes system settings or other programs'],
  [/\b(reg(?:\.exe)?\s+(?:add|delete|import|load|save|restore)|net\s+(?:user|localgroup|share|use|stop|start)|sc(?:\.exe)?\s+(?:create|delete|config|stop)|cipher\s+\/w)\b/i, 'changes system settings or accounts'],
  [/\s-(?:enc|encodedcommand|e)\s+[A-Za-z0-9+/=]{20,}/i, 'contains encoded PowerShell'],
  [/\b(iex|invoke-expression|downloadstring|downloadfile|start-bitstransfer)\b/i, 'downloads and runs code'],
  [/(?:curl|wget)\b[^\n]*\|\s*(?:bash|sh|cmd|powershell|pwsh)/i, 'pipes a download into a shell'],
  [/(?<![A-Za-z])[A-Za-z]:[\\/]/, 'uses a path outside the project folder'],
  [/(^|[\s"'=])\\\\[^\s\\]+\\/m, 'uses a network path'],
  [/(^|[\\/\s"'=])\.\.([\\/]|$|\s|["'])/m, 'leaves the project folder (..)'],
  [/%(?:userprofile|appdata|localappdata|programfiles(?:\(x86\))?|systemroot|windir|systemdrive|homepath|homedrive|programdata|public|temp|tmp|allusersprofile)%/i, 'uses system or user folders'],
  [/\bcd\s+(?:\/d\s+)?["']?[\\/](?!d\b)/i, 'changes to a drive root'],
  [/%~d0[\\/]/i, 'uses the drive root']
];
const DELETE_CMD = /\b(rmdir|rd|del|erase|rm|remove-item|ri)\b/i, RECURSIVE = /(\s\/s\b|\s-r\b|\s-rf\b|-recurse)/i;
const SAFE = new Set(['echo', 'rem', 'set', 'cd', 'pushd', 'popd', 'if', 'else', 'for', 'goto', 'pause', 'exit', 'call', 'setlocal', 'endlocal', 'where', 'python', 'python3', 'py', 'pip', 'pip3', 'pyinstaller', 'node', 'npm', 'npx', 'dotnet', 'go', 'cargo', 'rustc', 'gcc', 'g++', 'cl', 'msbuild', 'tsc', 'mkdir', 'md', 'copy', 'xcopy', 'move', 'ren', 'rename', 'type', 'cls', 'title', 'chcp', 'ver', 'timeout', 'del', 'erase', 'rmdir', 'rd', 'dir', 'color']);
const NETWORK = new Set(['pip', 'pip3', 'npm', 'npx', 'dotnet', 'cargo', 'go']);
const stripExt = (s) => s.replace(/\.(exe|cmd|bat|com)$/i, '');

function commandsOf(text) {
  const out = [];
  for (let line of text.split(/\r?\n/)) {
    line = line.replace(/\d*>&\d+/g, '').replace(/\d*>>?\s*[^\s&|()]+/g, '').replace(/<\s*[^\s&|()]+/g, '').trim(); if (!line || line.startsWith(':')) continue;
    for (let seg of line.split(/&&|\|\||[&|()]/)) {
      seg = seg.trim().replace(/^@/, ''); if (!seg) continue;
      seg = seg.replace(/^if\s+(?:not\s+)?(?:exist\s+(?:"[^"]*"|\S+)|errorlevel\s+\d+|defined\s+\S+|"[^"]*"\s*==\s*"[^"]*"|\S+\s*==\s*\S+)\s*/i, '').replace(/^else\s*/i, '').replace(/^for\s+.*?\sdo\s*/i, '').replace(/^call\s+/i, '');
      const m = seg.match(/^["']?([^\s"'>]+)/); if (m) out.push(stripExt(m[1].toLowerCase()));
    }
  } return out;
}
function unsafeDeletes(text) {
  const bad = [];
  for (const line of text.split(/\r?\n/)) {
    if (!DELETE_CMD.test(line) || !RECURSIVE.test(line)) continue;
    const toks = line.trim().split(/\s+/).slice(1).filter((t) => !/^[\/-]/.test(t));
    if (!toks.length || toks.some((t) => /^["']?(\.|\*|\*\.\*|[\\/]|~)["']?$/.test(t))) bad.push(line.trim());
  } return bad;
}
function classify(text) {
  const reasons = []; let risk = 'MEDIUM'; // running AI-written code is never "low"
  for (const [re, why] of FORBIDDEN) if (re.test(text)) { reasons.push(why); risk = 'FORBIDDEN'; }
  if (unsafeDeletes(text).length) { reasons.push('deletes broad folders'); risk = 'FORBIDDEN'; }
  if (risk !== 'FORBIDDEN') {
    const cmds = commandsOf(text), unknown = [...new Set(cmds.filter((c) => !SAFE.has(c)))];
    if (unknown.length) { risk = 'HIGH'; reasons.push('runs other programs: ' + unknown.slice(0, 6).join(', ')); }
    if (cmds.some((c) => NETWORK.has(c))) reasons.push('downloads packages from the internet');
    if (!reasons.length) reasons.push('runs only common build tools inside its own folder');
  }
  return { risk, reasons };
}
const BUILD_FILE = /^build\.(bat|cmd)$/i;
function previewBuild(dir) {
  let name; try { name = fs.readdirSync(dir).find((f) => BUILD_FILE.test(f)); } catch { return { error: 'Project folder not found.' }; }
  if (!name) return { error: 'This project has no build.bat.' };
  const full = path.join(dir, name); if (fs.statSync(full).size > 200000) return { error: 'The build script is too large to review.' };
  const text = fs.readFileSync(full, 'utf8');
  return { file: name, text, hash: crypto.createHash('sha256').update(text).digest('hex'), ...classify(text) };
}
function killTree(child) {
  if (process.platform === 'win32') spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
  else { try { process.kill(-child.pid, 'SIGKILL'); } catch { try { child.kill('SIGKILL'); } catch { /* gone */ } } }
}
function runProcess({ cmd, args = [], cwd, onOutput, onSpawn, signal, timeoutMs = 900000, env }) {
  return new Promise((resolve) => {
    let done = false, timedOut = false, cancelled = false, t;
    const child = spawn(cmd, args, { cwd, env, windowsHide: true, detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'] });
    const ab = () => { cancelled = true; killTree(child); };
    const finish = (r) => { if (done) return; done = true; clearTimeout(t); if (signal) signal.removeEventListener('abort', ab); resolve({ timedOut, cancelled, ...r }); };
    t = setTimeout(() => { timedOut = true; killTree(child); }, timeoutMs);
    if (signal) { if (signal.aborted) ab(); else signal.addEventListener('abort', ab, { once: true }); }
    if (onSpawn) onSpawn(child);
    child.stdout.on('data', (d) => onOutput && onOutput('stdout', d.toString()));
    child.stderr.on('data', (d) => onOutput && onOutput('stderr', d.toString()));
    child.on('error', (e) => finish({ code: null, error: e.message }));
    child.on('close', (code) => finish({ code }));
  });
}
function findExecutables(dir, sinceMs, depth = 5, out = []) {
  if (depth < 0 || out.length >= 20) return out;
  let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of ents) {
    if (e.name === 'node_modules' || e.name === '.git') continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) findExecutables(full, sinceMs, depth - 1, out);
    else if (/\.exe$/i.test(e.name) && fs.statSync(full).mtimeMs >= sinceMs) out.push(full);
  } return out;
}
module.exports = { classify, commandsOf, previewBuild, runProcess, killTree, findExecutables, BUILD_FILE };
