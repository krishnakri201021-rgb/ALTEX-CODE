'use strict';
const fs = require('fs'), path = require('path');
// Keys are encrypted with the OS keystore (Electron safeStorage) and never sent to the renderer.
class Store {
  constructor(file, crypto) { this.file = file; this.crypto = crypto; this.data = { consent: false, active: null, providers: {} }; this.load(); }
  load() { try { this.data = { consent: false, active: null, providers: {}, ...JSON.parse(fs.readFileSync(this.file, 'utf8')) }; } catch { /* first run */ } }
  save() { fs.mkdirSync(path.dirname(this.file), { recursive: true }); fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2)); }
  setKey(id, key) {
    if (!this.crypto.isAvailable()) throw new Error('Secure storage is not available on this system.');
    this.data.providers[id].enc = this.crypto.encrypt(key).toString('base64');
  }
  getKey(id) { const p = this.data.providers[id]; return p && p.enc ? this.crypto.decrypt(Buffer.from(p.enc, 'base64')) : null; }
  view() {
    return { consent: this.data.consent, active: this.data.active, providers: Object.entries(this.data.providers).map(([id, p]) => ({ id, name: p.name, baseUrl: p.baseUrl, connected: !!p.enc, models: p.models || [], model: p.model || null })) };
  }
}
module.exports = { Store };
