@echo off
cd /d "%~dp0"
title ALTREX CODE installer build
echo === ALTREX CODE: building the Windows installer ===
echo Folder: %CD%
echo.
echo [1/3] Installing packages (this can take a few minutes, please wait)...
call npm install --no-fund --no-audit --foreground-scripts
if errorlevel 1 goto fail
echo.
echo [2/3] Preparing Electron...
if not exist node_modules\electron\dist\electron.exe call node node_modules\electron\install.js
if errorlevel 1 goto fail
echo.
echo [3/3] Building the installer (first time downloads build tools)...
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npm run dist
if errorlevel 1 goto fail
echo.
echo Done. Your files are in the dist folder:
dir /b dist\*.exe
start "" "%~dp0dist"
pause
exit /b 0
:fail
echo.
echo FAILED. Copy the error text above and send it to ALTREX support chat.
pause
exit /b 1
